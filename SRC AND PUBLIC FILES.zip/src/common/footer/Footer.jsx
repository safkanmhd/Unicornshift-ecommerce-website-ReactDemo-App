import React from "react"
import "./style.css"

const Footer = () => {
  return (
    <>
      <footer>
        <div className="container grid2">
          <div className="box">
            <h1>UnicornShift</h1>
            <p>
              On-demand. Whether you’re looking for one or 100 Traffic
              Controllers, or if it’s last-minute or weeks away—all it takes is
              a single tap to crew your worksite with the right people
            </p>
            <div className="icon d_flex">
              <div className="img d_flex">
                <i class="fa-brands fa-google-play"></i>
                <span>Google Play</span>
              </div>
              <div className="img d_flex">
                <i class="fa-brands fa-app-store-ios"></i>
                <span>App Store</span>
              </div>
            </div>
          </div>

          <div className="box">
            <h2>About Us</h2>
            <ul>
              <li>Careers</li>
              <li>Our Stores</li>
              <li>Our Cares</li>
              <li>Terms & Conditions</li>
              <li>Privacy Policy</li>
            </ul>
          </div>
          <div className="box">
            <h2>Customer Care</h2>
            <ul>
              <li>Help Center </li>
              <li>How to Buy </li>
              <li>Track Your Order </li>
              <li>Corporate & Bulk Purchasing </li>
              <li>Returns & Refunds </li>
            </ul>
          </div>
          <div className="box">
            <h2>Contact Us</h2>
            <ul>
              <li>
                2020 © UnicornShift <br></br>Building 239 Innovation Campus ,
                Squires Way,<br></br>
                North Wollongong <br></br>NSW 2500 <br></br>ABN: 38 638 472 376{" "}
              </li>
              <li>Email: support@unicorn-shift.com</li>
              <li>Phone: +11 123 456 780</li>
            </ul>
          </div>
        </div>
      </footer>
    </>
  );
}

export default Footer
